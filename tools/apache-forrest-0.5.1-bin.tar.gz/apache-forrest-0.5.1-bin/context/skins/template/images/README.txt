Image files traditionally go here.  They are referenced in site2xhtml.xsl with
(for example):

<img src="{$skin-img-dir}/search-left.gif">
