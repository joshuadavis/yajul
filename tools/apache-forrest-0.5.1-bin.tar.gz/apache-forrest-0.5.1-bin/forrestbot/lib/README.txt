This directory contains jars required for Forrestbot operation.

If you want mail support (ie, you have <project sendlogto=".."), then you also
need to copy the following external jars to this directory:

activation.jar
mailapi.jar
smtp.jar

The first may be downloaded from:
  http://java.sun.com/products/javabeans/glasgow/jaf.html

JAF 1.0.2 is known to work.


The second two may be downloaded from:
  http://java.sun.com/products/javamail/index.html

JavaMail 1.2 is known to work.
