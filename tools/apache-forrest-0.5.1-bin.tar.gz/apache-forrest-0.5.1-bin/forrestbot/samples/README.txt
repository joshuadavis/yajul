This directory contains sample forrestbot scripts.  Most of these scripts are
being used by a forrestbot installation (http://forrestbot.cocoondev.org) to
build a selection of Forrest-using projects.

To run one of these scripts, type 'forrestbot -Dbot.config=<name>', where
<name> is the script.
