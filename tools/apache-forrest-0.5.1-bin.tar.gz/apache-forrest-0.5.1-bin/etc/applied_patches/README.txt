This directory contains information on how to rebuild various jars that Cocoon
depends on.  Specifically, it contains Forrest-specific patches applied to
versioned releases of software like Cocoon.

lib/core/cocoon-m2-patched.jar
- Applied patch cocoon-m2-selectorfix.diff, which gets the
  ResourceExistsSelector working from the command-line.
