package org.openfast.template;

public interface TemplateRegisteredListener {
	public void templateRegistered(MessageTemplate template, int templateId);
}
