package org.openfast.session;

import org.openfast.Message;

public interface MessageListener {
	void onMessage(Message message);
}
