package org.jboss.seam.jsf;
/**
 * @deprecated use TransactionalSeamPortletPhaseListener
 * @author Gavin King
 *
 */
public class SeamExtendedManagedPersistencePortletPhaseListener extends
      TransactionalSeamPortletPhaseListener
{
   private static final long serialVersionUID = 934882938114880667L;
}
