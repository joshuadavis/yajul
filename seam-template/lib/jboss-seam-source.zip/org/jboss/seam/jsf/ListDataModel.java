//$Id: ListDataModel.java,v 1.2 2006/12/21 02:38:27 sbryzak2 Exp $
package org.jboss.seam.jsf;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.List;
public class ListDataModel extends javax.faces.model.ListDataModel implements Serializable
{
   private static final long serialVersionUID = 5156131434571541698L;
   private void writeObject(ObjectOutputStream oos) throws IOException 
   {
      oos.writeObject( getWrappedData() );
      oos.writeInt( getRowIndex() );
   }
   private void readObject(ObjectInputStream ois) throws IOException, ClassNotFoundException 
   {
      this.setWrappedData( ois.readObject() );
      this.setRowIndex( ois.readInt() );
   }
   public ListDataModel()
   {
      super();
   }
   public ListDataModel(List list)
   {
      super(list);
   }
   
}
