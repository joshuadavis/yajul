package org.jboss.seam.jsf;
/**
 * @deprecated use TransactionalSeamPhaseListener
 * @author Gavin King
 *
 */
public class SeamExtendedManagedPersistencePhaseListener extends
      TransactionalSeamPhaseListener 
{
   private static final long serialVersionUID = -3050332015324532147L;
   
}
