@Namespace(value="http://jboss.com/products/seam/theme", prefix="org.jboss.seam.theme")
package org.jboss.seam.theme;

import org.jboss.seam.annotations.Namespace;
