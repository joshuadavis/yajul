//$Id: Logger.java,v 1.2 2007/02/05 05:05:26 gavin Exp $
package org.jboss.seam.annotations;

import static java.lang.annotation.ElementType.*;
import static java.lang.annotation.RetentionPolicy.RUNTIME;

import java.lang.annotation.Documented;
import java.lang.annotation.Retention;
import java.lang.annotation.Target;

/**
 * Injects a log
 * 
 * @author Gavin King
 */
@Target(FIELD)
@Retention(RUNTIME)
@Documented
public @interface Logger 
{
   /**
    * @return the log category
    */
   String value() default "";
}
