//$Id: RequestParameter.java,v 1.5 2007/02/16 16:49:03 gavin Exp $
package org.jboss.seam.annotations;

import static java.lang.annotation.ElementType.FIELD;
import static java.lang.annotation.ElementType.METHOD;
import static java.lang.annotation.RetentionPolicy.RUNTIME;

import java.lang.annotation.Documented;
import java.lang.annotation.Retention;
import java.lang.annotation.Target;

/**
 * Injects a request parameter value
 * 
 * @author Gavin King
 */
@Target({METHOD, FIELD/*, PARAMETER*/})
@Retention(RUNTIME)
@Documented
public @interface RequestParameter 
{
   /**
    * The name of the request parameter
    */
   String value() default "";
}
