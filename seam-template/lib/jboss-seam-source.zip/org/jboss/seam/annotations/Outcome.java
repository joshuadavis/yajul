//$Id: Outcome.java,v 1.4 2006/10/10 04:48:21 gavin Exp $
package org.jboss.seam.annotations;

public class Outcome
{
   /**
    * Annotations may not specify a null String. This
    * value lets us specify a null outcome in an
    * annotation such as @IfInvalid
    */
   public static final String REDISPLAY = "org.jboss.seam.outcome.null";
}
