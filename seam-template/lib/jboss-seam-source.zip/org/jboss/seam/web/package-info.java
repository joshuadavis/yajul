@Namespace(value="http://jboss.com/products/seam/web", prefix="org.jboss.seam.web")
package org.jboss.seam.web;

import org.jboss.seam.annotations.*;
