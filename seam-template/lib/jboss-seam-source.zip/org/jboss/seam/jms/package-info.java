@Namespace(value="http://jboss.com/products/seam/jms",prefix="org.jboss.seam.jms")
package org.jboss.seam.jms;

import org.jboss.seam.annotations.Namespace;
