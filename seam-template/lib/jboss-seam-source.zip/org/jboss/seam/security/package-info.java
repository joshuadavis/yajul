@Namespace(value="http://jboss.com/products/seam/security", prefix="org.jboss.seam.security")
package org.jboss.seam.security;

import org.jboss.seam.annotations.Namespace;
