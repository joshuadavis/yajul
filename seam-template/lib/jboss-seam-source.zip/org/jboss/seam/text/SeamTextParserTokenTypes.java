// $ANTLR 2.7.6 (2005-12-22): "seam-text.g" -> "SeamTextLexer.java"$

package org.jboss.seam.text;

public interface SeamTextParserTokenTypes {
	int EOF = 1;
	int NULL_TREE_LOOKAHEAD = 3;
	int WORD = 4;
	int PUNCTUATION = 5;
	int ESCAPE = 6;
	int STAR = 7;
	int SLASH = 8;
	int BAR = 9;
	int HAT = 10;
	int PLUS = 11;
	int EQ = 12;
	int HASH = 13;
	int TWIDDLE = 14;
	int UNDERSCORE = 15;
	int OPEN = 16;
	int CLOSE = 17;
	int QUOTE = 18;
	int GT = 19;
	int LT = 20;
	int DOUBLEQUOTE = 21;
	int AMPERSAND = 22;
	int BACKTICK = 23;
	int SPACE = 24;
	int NEWLINE = 25;
}
