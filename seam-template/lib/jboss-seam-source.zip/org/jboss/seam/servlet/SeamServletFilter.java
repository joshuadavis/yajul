package org.jboss.seam.servlet;

import org.jboss.seam.web.ContextFilter;

/**
 * Manages the Seam contexts associated with a request to any servlet.
 * 
 * @author Gavin King
 */
@Deprecated
public class SeamServletFilter extends ContextFilter 
{
   
}
