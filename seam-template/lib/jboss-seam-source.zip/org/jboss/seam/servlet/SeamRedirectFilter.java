package org.jboss.seam.servlet;

import org.jboss.seam.web.RedirectFilter;

/**
 * Propagates the conversation context across a browser redirect
 * 
 * @author Gavin King
 */
@Deprecated
public class SeamRedirectFilter extends RedirectFilter 
{
   
}
