@Namespace(value="http://jboss.com/products/seam/core", prefix="org.jboss.seam.core")
package org.jboss.seam.core;

import org.jboss.seam.annotations.*;
