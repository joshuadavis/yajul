package org.jboss.seam;

public enum InterceptorType
{
   CLIENT,
   SERVER,
   ANY
}
