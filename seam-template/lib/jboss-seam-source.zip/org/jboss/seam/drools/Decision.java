package org.jboss.seam.drools;

public class Decision
{
   private String outcome;

   public String getOutcome()
   {
      return outcome;
   }

   public void setOutcome(String outcome)
   {
      this.outcome = outcome;
   }
}
