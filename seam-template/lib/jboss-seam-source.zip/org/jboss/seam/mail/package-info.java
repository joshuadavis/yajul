@Namespace(value="http://jboss.com/products/seam/mail",prefix="org.jboss.seam.mail")
package org.jboss.seam.mail;

import org.jboss.seam.annotations.Namespace;
