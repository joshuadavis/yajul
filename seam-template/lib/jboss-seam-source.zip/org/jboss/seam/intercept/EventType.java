package org.jboss.seam.intercept;

public enum EventType
{
   AROUND_INVOKE,
   PRE_DESTORY,
   POST_CONSTRUCT,
   PRE_PASSIVATE,
   POST_ACTIVATE
}
