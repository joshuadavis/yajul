@Namespace(value="http://jboss.com/products/seam/framework", prefix="org.jboss.seam.core.framework")
package org.jboss.seam.framework;

import org.jboss.seam.annotations.Namespace;
