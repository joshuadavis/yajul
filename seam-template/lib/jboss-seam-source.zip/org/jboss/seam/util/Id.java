//$Id: Id.java,v 1.2 2006/10/10 21:00:53 gavin Exp $
package org.jboss.seam.util;

import java.util.concurrent.atomic.AtomicInteger;

public class Id
{
   private static AtomicInteger uniqueId = new AtomicInteger(0);
   
   public static String nextId() 
   {
      //TODO: this is not cluster safe!!!!!
      return Integer.toString( uniqueId.incrementAndGet() );
   }
}
