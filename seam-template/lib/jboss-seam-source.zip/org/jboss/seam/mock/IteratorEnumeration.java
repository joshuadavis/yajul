//$Id: IteratorEnumeration.java,v 1.1 2005/08/24 04:15:09 gavin Exp $
package org.jboss.seam.mock;

import java.util.Enumeration;
import java.util.Iterator;

public class IteratorEnumeration implements Enumeration
{
   
   private Iterator iterator;
   
   IteratorEnumeration(Iterator iterator)
   {
      this.iterator = iterator;
   }

   public boolean hasMoreElements()
   {
      return iterator.hasNext();
   }

   public Object nextElement()
   {
      return iterator.next();
   }

}
